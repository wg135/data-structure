#ifndef __GUITARTAB_C__
#define __GUITARTAB_C__

//#include <pthread.h>		//plan to use divide and conquer to divide the chords into several part....
#include <limits.h>
#include <float.h>
#include <math.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Read "guitarTab-config" /////////////////////////////////////////////////////////////
#include "guitarTab-config"

typedef unsigned long ulong;
typedef unsigned int  uint;
typedef unsigned char byte;

ulong  N;						
ulong  M;                     // for resetting node fitness

int   NoteStringArray[512];
ulong PitchPositionArray[108]; 

#define VCHORDSIZE 2048 
#define VNOTESIZE 7
#define bufferSize 256

#define position2Char(string,fret) (((string)<<5)+(fret)+1)
#define char2String(c)             (((byte)(c))>>5)
#define char2Fret(c)               ((31&((byte)(c)))-1)

typedef struct node_tag
{
    ulong            c; // for initialization/reset
    ulong            d; // data (chord position)
    ulong            s; // max, min (bottom 16 bits)
    ulong            p; // pitches (notes)
    float            f; // within_chord fitness
    float            a; // average fret position
    double           r; // fitness from root
    struct node_tag *n; // next
} node;

typedef node **chords, **path;

typedef struct
{
    int     s; // number of paths
    path   *b; // array of paths
    double *f; // fitness from root
    ulong  *n; // path sizes
} paths;

typedef struct pathElement 
{
	int j;			//possibility index 
	int k;			//the ith best path
	float f;		//fitness
}pathElement;

typedef struct ParseMidi
{
	int time;		//current time
	int ChordCount;	//chord index
	int offset;		//midi file offset
	int pitch;		//current pitch
	int deltaTime;	//delta time for the current note
	bool lastNote;	//used to determine chord
	int pitchArray[128];	//used to store the starting time for the pitch
}ParseMidi;

typedef unsigned long DWORD; //length: 4
typedef struct MidiHeaderChunk
{
	char    chunkID[5];
	DWORD   chunkSize;	//length: 6
	DWORD   format;		//format: 0, 1, 2
	DWORD   tracksNumber;
	DWORD	deltaTimeTicks;
}MidiHeaderChunk;
#define parseverbose 1

//open string note for the 6-string-guitar, middle C is 4C
static char *guitarString[] = {"4e", "3b", "3g", "3d", "2a", "2e", NULL};
static char *pianoKeyBoard[] = {"c","c+d-","d", "d+e-","e","f","f+g-","g","g+a-","a","a+b-","b"};
static int PIANOOCTAVEKEYNUMBER = sizeof(pianoKeyBoard) / sizeof(pianoKeyBoard[0]);      //size 12
//"is" means sharp(#), "es" means flat(b)
//"isis" mean double sharp(##), "eses" means double flat(bb)
static char *pianoNote[] = {"c", "cis", "d", "dis", "e", "f", "fis", "g", "gis", "a", "ais", "b", NULL};

#define STR(s) #s
#define C STR(%*[^\n]\n)
#define S SPREAD_PENALTY
#define EXPECT(a,b) if ((a) != (b)){ fclose(f); return 1; }

int read_config()
{
  FILE *f;
  if (!(f = fopen("guitarTab-config","r"))) return 1;
  EXPECT(6,fscanf(f,"float SPREAD_PENALTY[6] = {%f,%f,%f,%f,%f,%f};" C, S,S+1,S+2,S+3,S+4,S+5));
  EXPECT(1,fscanf(f,"int   FRET_MAX          = %d;" C, &FRET_MAX));
  EXPECT(1,fscanf(f,"int   HIGH_FRET         = %d;" C, &HIGH_FRET));
  EXPECT(1,fscanf(f,"int   BEST_RESULT       = %d;" C, &BEST_RESULT));
  EXPECT(1,fscanf(f,"int   OPEN_STRING       = %d;" C, &OPEN_STRING));
  EXPECT(1,fscanf(f,"int   LARGE_FRET        = %d;" C, &LARGE_FRET));
  EXPECT(1,fscanf(f,"int   BROKEN_TIE        = %d;" C, &BROKEN_TIE));
  EXPECT(1,fscanf(f,"int   RINGING           = %d;" C, &RINGING));
  EXPECT(1,fscanf(f,"int   MEASURE_DURATION  = %d;" C, &MEASURE_DURATION));
  fclose(f); return 0;
}

#undef STR
#undef C
#undef S
#undef EXPECT


void parseTrackMidiFile(FILE *midifp, FILE *fp, ParseMidi *pm, int trackIndex, 
		ulong vChord[VCHORDSIZE][VNOTESIZE], int vTrackTime[VCHORDSIZE]);
int MidiToKeyNumber(int MidiNumber);
void KeyNumberToNote(int PianoKeyNumber, char *n);

/**************************************************************
Midi file -> internal data structure
**************************************************************/
//get a fixed length(bits) word.
int getNumber(int bits, FILE *midifp, int *offset)
{
	int number=0;
	unsigned char ctemp = '\0';
	*offset += bits;
	while (bits--)
	{
		if ( midifp!=NULL )
			ctemp = getc(midifp);
		else
		{
			fprintf(stderr, "fp not available.\n");
			exit(0);
		}
		number = (number<<8) | ctemp;
	}
	return number;
}

//get a variable length word.
DWORD getDWord(FILE *midifp, int *offset)
{
	DWORD length = 0;
	unsigned char c = '\0';
	if ( (length=getc(midifp)) & 0x80 )
	{
		(*offset)++;
		length = length& 0x7f;
		do
		{
			length = (length<<7) + ((c=getc(midifp))&0x7f);
		} while (c&0x80);
	}
	return length;
}

void parseDWordContent(FILE *midifp, int type, FILE *fp, bool print, int *offset)
{
	FILE *f = NULL;
	if(print)
		f = fp;
	else	//	/dev/null is only for linux, nul is for linux and windows
		f = fopen("/dev/null", "w");
	//	f = fopen("nul", "w");
	if(f == NULL)
		fprintf(stderr, "Midi2XML.c: parseDWordContent: NULL fp.\n");

	DWORD length = getDWord(midifp, offset);
	int i;
	for (i=0; i<length; i++)
	{
		unsigned char ctemp = getc(midifp);
		if (type)// print the ASCII content
			fprintf(f, "%c", ctemp);
		else//system sysex event
			fprintf(f, "%x ", ctemp);
	}
	fprintf(f, "\n");

	if(print == false)
		fclose(f);
}

int parseMetaEvent(FILE *midifp, FILE *fp, bool print, int *offset)
{//ff -> meta event
	FILE *f = NULL;
	if(print)
		f = fp;
	else
		f = fopen("/dev/null", "w");
	//	f = fopen("nul", "w");
	if(f == NULL)
		fprintf(stderr, "Midi2XML.c: parseDWordContent: NULL fp.\n");

	unsigned char metaType = getc(midifp); //subtype of meta event
	*offset+=1;
	int itemp = 0, c1=0, c2=0, c3=0, c4=0, c5=0;

	switch (metaType)
	{
	case 0x00:
		fprintf(f, "    <SequenceNumber Value=\"0x%x\" ) ", metaType);
		itemp = getDWord(midifp, offset);
		if (itemp==2)
		{
			c1=getc(midifp);
			c2=getc(midifp);
			*offset += 2;
			fprintf(f, "MSB=\"%d\" LSB=\"%d\"/>", c1, c2);
		}
		else
		{
			fprintf(stderr, "%s %s: Length of this section is not 2.\n", __FILE__, __FUNCTION__);
			exit(0);
		}
		break;
	//0x01~0x07 string contents
	case 0x01:
		fprintf(f, "    <TextEvent Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x02:
		fprintf(f, "    <CopyRight Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x03:
		fprintf(f, "    <SequenceOrTrackName Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x04:
		fprintf(f, "    <InstrumentName Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x05:
		fprintf(f, "    <Lyric Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x06:
		fprintf(f, "    <Marker Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x07:
		fprintf(f, "    <CuePoint Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	case 0x32:/*20*/
		fprintf(f, "    <ChannelPrefix Value=\"0x%x\" ", metaType);
		if ( getDWord(midifp, offset) == 1)
		{
			c1=getc(midifp);
			*offset += 1;
			fprintf(f, "ChannelNumber=%d/>\n", c1);
		}
		else
		{
			fprintf(stderr, "%s %s: Length of MIDI Channel Prefix is not 1.\n", __FILE__, __FUNCTION__);
			exit(0);
		}
		break;
	case 0x2f:/*47*/
		fprintf(f, "    <EndOfTrack Value=\"0x%x\" />\n", metaType);
		if( getDWord(midifp, offset) != 0)
		{
			fprintf(stderr, "%s %s: Length of End of Track is not 0.\n", __FILE__, __FUNCTION__);
			exit(0);
		}
		if(print == false)
			fclose(f);
		return true;
	case 0x51:/*81*/
		fprintf(f, "    <SetTempo Value=\"0x%x\" ", metaType);
		itemp = getDWord(midifp, offset);
		if (itemp==3)
		{
			itemp = getNumber(3, midifp, offset);
			//BPM = 60,000,000/(tt tt tt)
			//BPM(Beats Per Minute): a tempo of 100 BPM means that 100 quarter notes per minute
			fprintf(f, "MicrosecondsPerQuarterNote=\"%d\" BPM=\"%d\" />\n", 
					itemp, 60000000/itemp);
		}
		else
		{
			fprintf(stderr, "%s %s %d: Length of Set Tempo is not 3.\n", __FILE__, __FUNCTION__, __LINE__);
			exit(0);
		}
		break;
	case 0x54:/*84*/
		fprintf(f, "    <SMPTEOffset Value=\"0x%x\" ", metaType);
		itemp = getDWord(midifp, offset);
		if (itemp==5)
		{
			c1=getc(midifp);
			c2=getc(midifp);
			c3=getc(midifp);
			c4=getc(midifp);
			c5=getc(midifp);
			*offset += 5;
			fprintf(f, "Hour=\"%d\" Min=\"%d\" Sec=\"%d\" Fr=\"%x\" SubFr=\"%d\"/>\n", c1, c2, c3, c4, c5);
		}
		else
		{
			fprintf(stderr, "%s %s %d: Length of SMPTE Offset is not 5.\n", __FILE__, __FUNCTION__, __LINE__);
			exit(0);
		}
		break;
	case 0x58:/*88*/
		fprintf(f, "    <TimeSignature Value=\"0x%x\" ", metaType);
		itemp = getDWord(midifp, offset);
		if (itemp==4)
		{
			c1=getc(midifp);
			c2=getc(midifp);
			c3=getc(midifp);
			c4=getc(midifp);
			*offset += 4;
			fprintf(f, " Numerator=\"%d\" LogDenominator=\"%x\" ", c1, c2);
			fprintf(f, "MIDIClocksPerMetronomeClick=\"%x\" ThirtySecondsPer24Clocks=\"%d\"/>\n", c3, c4);
		}
		else
		{
			fprintf(stderr, "%s %s %d: Length of Time Signature is not 4.\n", __FILE__, __FUNCTION__, __LINE__);
			exit(0);
		}
		break;
	case 0x59:
		fprintf(f, "    <KeySignature Value=\"0x%x\" ", metaType);
		if(getDWord(midifp, offset) == 2)
		{
			c1=getc(midifp);
			c2=getc(midifp);
			*offset += 2;
			fprintf(f, " Fifths=\"%d\"", c1);
			if(parseverbose)
			{
				switch (c1)
				{
					case -7:
						fprintf(f, "(7flats) ");
						break;
					case -1:
						fprintf(f, "(1flat) ");
						break;
					case 0:
						fprintf(f, "(keyofC) ");
						break;
					case 1:
						fprintf(f, "(1sharp) ");
						break;
					case 7:
						fprintf(f, "(7sharps) ");
						break;
				}
			}
			fprintf(f, " Mode=\"%d\"", c2);
			if(parseverbose)
			{
				switch (c2)
				{
					case 0:
						fprintf(f, " Key=\"MajorKey\"");
						break;
					case 1:
						fprintf(f, " Key=\"MinorKey\"");
						break;
				}
			}
			fprintf(f, "/>\n");
		}
		else
		{
			fprintf(stderr, "%s %s %d: Length of Key Signature is not 2.\n", __FILE__, __FUNCTION__, __LINE__);
			exit(0);
		}
		break;
	case 0x7f:
		fprintf(f, "    <SequencerSpecificInformation Value=\"0x%x\" ) />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	default:
		fprintf(f, "    <Unknown meta event Value=\"0x%x\" />\n", metaType);
		parseDWordContent(midifp, 1, f, true, offset);
		break;
	}
	if(print == false)
		fclose(f);
	return false;
}

bool checkSameNote(ulong vchord[VNOTESIZE], int pitch)
{
	int i = 0;
	for(i=0; i<vchord[VNOTESIZE-1]; i++)
		if(pitch == (vchord[i]>>32))
			return true;
	return false;
}

//vTrackTime[0]:size
//N: size for 1th D
//vChord[N][VNOTESIZE-1]: size for 2th D
void storeNote(ParseMidi *pm, ulong vChord[VCHORDSIZE][VNOTESIZE], int vTrackTime[VCHORDSIZE])
{
	if(N>VCHORDSIZE)
	{
		fprintf(stderr, "Too Many notes: %ld > %d.\n", N, VCHORDSIZE);
		return;
	}

	int pitch = pm->pitch;
	int duration = pm->time - pm->pitchArray[pitch];

	//store the pair(pitch, duration) in the vChord
    ulong pnote = ( ((ulong)pitch<<32) | duration );

	bool find = false;
    int i = 1;
    for(i=1; i<=vTrackTime[0]; i++)	//vTrackTime[0] used as size
    {
		if(vTrackTime[i] == pm->pitchArray[pitch])	//starting time
        {
			if(vChord[i-1][VNOTESIZE-1] < sizeof(ulong) && 
				checkSameNote(vChord[i-1], pitch) == false)
			{
				vChord[i-1][ vChord[i-1][VNOTESIZE-1] ] = pnote;
	               vChord[i-1][VNOTESIZE-1]++;	//size ++
			}
            find = true;
            break;
        }

        //need to add a new starting time
        if(vTrackTime[i] > pm->pitchArray[pitch])
        {
			//move existing vChord chords
            int j, k;
            for(j=N; j>=i-1; j--)
				for(k=0; k<VNOTESIZE; k++)
					vChord[j+1][k] = vChord[j][k];

			vChord[i-1][j] = 0;
            vChord[i-1][0] = pnote;
            vChord[i-1][VNOTESIZE-1] = 1;
            N++;

            memmove(&(vTrackTime[i+1]), &(vTrackTime[i]), sizeof(int)*(vTrackTime[0]-i+1));
            vTrackTime[i] = pm->pitchArray[pitch];	//starting time
            vTrackTime[0] ++;	//size++

            find = true;
            break;
        }
    }

    //can't find a right place, add the note to the end of vChord
    if(find == false)
    {
       vChord[N][0] = pnote;
       vChord[N][VNOTESIZE-1] = 1;
       N++;

       vTrackTime[0]++;
       vTrackTime[ vTrackTime[0] ] = pm->pitchArray[pitch];
    }
}

void parseMidiHeaderChunk(FILE *midifp, MidiHeaderChunk *MIDIHead, int *offset)
{
	if (	(!fscanf(midifp, "%4s", MIDIHead->chunkID) || strcmp(MIDIHead->chunkID, "MThd"))	||
	        (!(MIDIHead->chunkSize=getNumber(4, midifp, offset)) || MIDIHead->chunkSize!=6 )
	   )
	{
		fprintf(stderr, "%s: %s", __FILE__, __FUNCTION__);
		exit(0);
	}
	MIDIHead->format=getNumber(2, midifp, offset);
	MIDIHead->tracksNumber=getNumber(2, midifp, offset);
	MIDIHead->deltaTimeTicks=getNumber(2, midifp, offset);
//	printMidiHeaderChunk(*MIDIHead, fp);
}

void parseMidiEvent(int head, FILE *midifp, FILE *fp, ParseMidi *pm, ulong vChord[VCHORDSIZE][VNOTESIZE],
		int trackIndex, int vTrackTime[VCHORDSIZE])
{//8-E

	int itemp, c1, c2;
	int channelNumber = (head&0x0f);

	switch (head>>4)
	{
	case 0x8://note off
		c1=getc(midifp);
		c2=getc(midifp);
		pm->offset+=2;
		pm->lastNote=false;
		char n[5];	
		KeyNumberToNote(MidiToKeyNumber(c1), n);
		fprintf(fp, "    <NoteOff Channel=\"%d\" Pitch=\"%d\" Note=\"%s\" Velocity=\"%d\"/>\n", 
				channelNumber, c1, n, c2);
		printf("    <NoteOff Channel=%d Pitch=%d Note=%s Velocity=%d, Delta=%d/>\n", 
				channelNumber, c1, n, c2, pm->deltaTime);
		break;
	case 0x9://note on
		c1=getc(midifp);	//pitch
		c2=getc(midifp);	//velocity

		pm->offset+=2;
		pm->lastNote=true;
		pm->pitch = c1;

		//note off event: velocity is 0
		if(c2 == 0) 
			storeNote(pm, vChord, vTrackTime);
		else
			pm->pitchArray[c1] = pm->time;	//record the starting time for pitch c1
	
		KeyNumberToNote(MidiToKeyNumber(c1), n);
		fprintf(fp, "    <NoteOn Number=\"%d\" Channel=\"%d\" Pitch=\"%d\" Note=\"%s\" Velocity=\"%d\"/>\n", 
			pm->ChordCount, channelNumber, c1, n, c2);
		break;
	case 0xA:
		c1=getc(midifp);
		c2=getc(midifp);
		pm->offset+=2;
		fprintf(fp, "    <KeyAfterTouch Channel=\"%d\" Pitch=\"%d\" Amount=\"%x\"/>\n", 
				channelNumber, c1, c2);
		break;
	case 0xB:
		c1=getc(midifp);
		c2=getc(midifp);
		pm->offset+=2;
		fprintf(fp, "    <ControlChange Channel=\"%d\" Control=\"%d\" Value=\"%d\"/>\n", 
				channelNumber, c1, c2);
		break;
	case 0xC:
		c1=getc(midifp);
		pm->offset+=1;
		fprintf(fp, "    <ProgramChange Channel=\"%d\" NewProgramNumber=\"%d\"/>\n", 
				channelNumber, c1);
		break;
	case 0xD:
		c1=getc(midifp);
		pm->offset+=1;
		fprintf(fp, "    <ChannelAfterTouch Channel=\"%d\" ChannelNumber=\"%d\"/>\n", 
				channelNumber, c1);
		break;
	case 0xE:
		c1=getc(midifp);
		c2=getc(midifp);
		pm->offset+=2;
		fprintf(fp, "    <PitchWheelChange Channel=\"%d\" BottomValue=\"%d\" TopValue=\"%d\"/>\n", 
				channelNumber, c1, c2);
		break;
	case 0xF:
		itemp = getDWord(midifp, &pm->offset);
		fprintf(fp, "    <SysxMessage with %d octets/>\n", itemp);
		//getNumber(itemp, fp);
		break;
	default:
		fprintf(fp, "    <MidiEvent should be added(%d)/>\n", head);
		break;
	}
}

//input Lilypond format file to vChord(pitch, duration) and playing time(starting time, ending time)
int Midi2XML2(char * MidiFileName, char *XMLFileName, ulong vChord[VCHORDSIZE][VNOTESIZE])
{
	//open midi file
	FILE *midifp = fopen(MidiFileName, "rb");
	FILE *fp = fopen(XMLFileName, "w");
	if (midifp==NULL || fp==NULL)
	{
		fprintf(stderr, "%s %d %s: Can't open midi file %s.\n", 
				__FILE__, __LINE__, __FUNCTION__, MidiFileName);
		exit(0);
	}

	ParseMidi pm;
	memset(&pm, 0, sizeof(ParseMidi));

	fprintf(fp, "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n");
	fprintf(fp, "<!DOCTYPE MIDIFile PUBLIC\n");
	fprintf(fp, "  \"-//Recordare//DTD MusicXML 0.9 MIDI//EN\"\n");
	fprintf(fp, "  \"http://www.musicxml.org/dtds/midixml.dtd\">\n");
	fprintf(fp, "<MIDIFile>\n");

	//read midi file head chunk
	MidiHeaderChunk MIDIHead;
	parseMidiHeaderChunk(midifp, &MIDIHead, &pm.offset);

    memset(vChord, 0, sizeof(vChord));
	int vTrackTime[VCHORDSIZE];	//starting time for each chord
    memset(vTrackTime, 0, VCHORDSIZE*sizeof(int));
	
	//read midi file track chunks head
	int i;
	for (i=0; i<MIDIHead.tracksNumber; i++)
	{
		pm.ChordCount = pm.time = pm.deltaTime = pm.lastNote = 0;
			
		fprintf(fp, "<Track Number=\"%d\">\n", i);
		parseTrackMidiFile(midifp, fp, &pm, i, vChord, vTrackTime);
		fprintf(fp, "</Track>\n");
	//	int j = 0;
	//	for(j=0; j<N; j++)
	//		printf("time %d\n", vTrackTime[j]);
	}

	fprintf(fp, "</MIDIFile>\n");

	//close midi file
	fclose(midifp);
	fclose(fp);
//	printf("trackNO: %ld.\n", MIDIHead.tracksNumber);
	//find out the track number
	int trackNumber = 0;
	for(i=0; i<N; i++)
	{
		if(trackNumber < vChord[i][VNOTESIZE-1])
			trackNumber = vChord[i][VNOTESIZE-1];
	}
	return trackNumber;
	//	return MIDIHead.tracksNumber;
}

//parse midi track
void parseTrackMidiFile(FILE *midifp, FILE *fp, ParseMidi *pm, int trackIndex, 
		ulong vChord[VCHORDSIZE][VNOTESIZE], int vTrackTime[VCHORDSIZE])
{
	//printf("Track %d:\n", trackIndex);
    
	memset(pm, '\0', sizeof(ParseMidi));

	unsigned char ctemp[5], ctemp1='\0';
	memset(ctemp, '\0', 5);
	int itemp=0, finished=false, deltaTime=0;

	//track chunk head: MTrk
	if (	(!fscanf(midifp, "%4s", ctemp) || strcmp((char *)ctemp, "MTrk"))	
        //track chunk size;
    ||	(!(itemp = getNumber(4, midifp, &(pm->offset))))
   )
		fprintf(stderr, "%s: %s: Error Midi Head Chunk.\n", __FILE__, __FUNCTION__);
	if(parseverbose)
		fprintf(fp, "<Track Size=\"%d\"/>\n", itemp);

	//read event
	while (!finished)
	{
		deltaTime = getDWord(midifp, &pm->offset);
		pm->time = pm->time + deltaTime;
		pm->deltaTime = deltaTime;	//used for check whether it is a new chord

		fprintf(fp, "  <Event>\n");
		fprintf(fp, "    <Delta>%d</Delta>\n", pm->deltaTime);

		if(pm->deltaTime!=0 && pm->lastNote==true)	//a new chord
			pm->ChordCount++;
		
		if(parseverbose)
		{
			fprintf(fp, "    <Absolute>%d</Absolute>\n", pm->time);
			fprintf(fp, "    <OffSet>%d</OffSet>\n", pm->offset);
		}

			ctemp1 = getc(midifp);
			if ( ctemp1 && 0x80 )
			{
				if (ctemp1==0xff)
				{
					if(parseverbose) 
						fprintf(fp, "  <MetaEvent Value=\"0x%x\">", ctemp1);
					finished = parseMetaEvent(midifp, fp, true, &(pm->offset));
					if(parseverbose) 
						fprintf(fp, "</MetaEvent>");
					
					//last note
					if(finished && trackIndex != 0)
					{	
					//	printf("ChordIndex: %d Time: %d Note: %d\n", 
					//			pm->ChordCount+1, pm->lastTime, pm->lastPitch);
						storeNote(pm, vChord, vTrackTime);
					}
				}
				else
				{
					if ((ctemp1>>4)==0xf)
					{
						if(parseverbose)
							fprintf(fp, "  <SysexEvent Value=\"0x%x\">", ctemp1);
						parseDWordContent(midifp, 0, fp, true, &pm->offset);
						if(parseverbose) 
							fprintf(fp, "  </SysexEvent>");
					}
					else
					{
						if (ctemp1>>4)
						{
							if(parseverbose)
								fprintf(fp, "  <MidiEvent Value=\"0x%x\">", ctemp1);
							parseMidiEvent(ctemp1, midifp, fp, pm, vChord,
									trackIndex, vTrackTime);
							if(parseverbose) 
								fprintf(fp, "  </MidiEvent>");
						}
						else
						{
							fclose(fp);
							ctemp[0]=ctemp1;
							ctemp[1]='\0';
							fprintf(stderr, "%s %s %d: Wrong Midi Event", __FILE__, __FUNCTION__, __LINE__);
							exit(0);
						}
					}
				}
			}
			else
			{
				fprintf(fp, "Useless data: %x\n", ctemp1);
				//printErrorMsg(ERROR_midiEvent, (void *)NULL);
			}
			fprintf(fp, "  </Event>\n");
		}
}


/**************************************************************
LilyPond format file -> internal data structure
**************************************************************/
//convert pitch number to Helmholtz pitch notation
void convertPitch2HPN(char pitchName[bufferSize], unsigned int pitch)
{
//	strcat(pitchName, "\\relative c ");
	
	strcat(pitchName, " ");
	int O = pitch % 12;	//Note Name Index
	strcat(pitchName, pianoNote[O]);
	
	int N = pitch / 12;		//in which octave 
	char c[3]; c[0]=c[1]=c[2]='\0';
	
	//middle C: 4C
	if(N >= 4)
		N = N-4, c[0] = '\'';
	else
		if(N < 4)
			N = 4-N, c[0] = ',';
	
	for(N = abs(N); N>0; --N)
		strcat(pitchName, c);
}

int checkStringComment(char *str) //is string a comment?
{
    for (; *str == ' ' || *str == '\t'; ++str);
    return (*str == '%');
}

//convert char Helmholtz pitch notation to pitch (return -1 for rest)
int convertHPN2Pitch(char *str)
{
    int i, note, octave = 4;                               // default octave

    if (*str == 'r') return -1;                            // rest
    for (note = 0; pianoNote[note]; note++)                // find note
        if (*str == *pianoNote[note]) {
            i = 1;
            if (str[1] == 'i' && str[2] == 's') i = 3, note++; // sharp
            while (str[i]=='\'') i++, octave++;
            while (str[i]==',' ) i++, octave--;
            return 12*octave + note;
        }
    return 0;                                              // note not found
}

int parseDuration(char *str) // find and convert first number
{
    char *p;
    int d = 0;

    for (; *str; ++str) if ('0' <= *str && *str <= '9') break; // find first digit
    for (p = str; *p; p++) {                                  // traverse digits
        if (*p < '0' || '9' < *p) return d;                     // done
        d += 10*d + *p-'0';                                     // compute value
    }
    fprintf(stderr,"Missing Duration\n");
    return 1;
}

//Input: track string, vChord result, the starting index for the measure,
//              the track index, a vector which keeps the starting time for each note
void parseTrack(char *str, ulong vChord[VCHORDSIZE][VNOTESIZE],
                int vChordIndex, int trackIndex, int *vTrackTime)
{
    char *p;
    unsigned int pitch, newTrackTime = 0;
    double triplet = 1;

    for (; ((p = strstr(str," "))); str = p)
    {
        *(p++) = 0;
        do if (*str != ' ' && *str != '\t') break;
        while (*++str); // remove leading whitespace
        if (*str) {
            //find a note
            pitch = UINT_MAX;
            if ('a' <= *str && *str <= 'g') pitch = convertHPN2Pitch(str);
            else if( *str == 'r')           pitch = UINT_MAX;

            if (pitch != UINT_MAX)
            {
                //find out the duration and store the pair in the vChord
                unsigned int duration = (unsigned int)MEASURE_DURATION*triplet/parseDuration(p);
                ulong pnote = ( ((ulong)pitch<<32) | duration );

                //if it is the first track, insert into vChord directly
                if (!trackIndex) {
                    vChord[N][0] = pnote;
                    vChord[N][VNOTESIZE-1]++;
                    N++;	//vChord.size ++

                    vTrackTime[0]++;
                    vTrackTime[ vTrackTime[0] ] = newTrackTime;
                }
                else	//try to find the right place
                {
                    bool find = false;
                    int i = 1;
                    for(i=1; i<=vTrackTime[0]; i++)	//vTrackTime[0] used as size
                    {
                        if(vTrackTime[i] == newTrackTime)
                        {
                            vChord[vChordIndex + i - 1][ vChord[vChordIndex+i-1][VNOTESIZE-1] ] = pnote;
                            vChord[vChordIndex + i - 1][VNOTESIZE-1]++;	//size ++
                            find = true;
                            break;
                        }

                        //need to add a new starting time
                        if(vTrackTime[i] > newTrackTime)
                        {
                            //move existing vChord chords
                            int j, k;
                            for(j=N; j>=vChordIndex+i-1; j--)
                                for(k=0; k<VNOTESIZE; k++)
                                    vChord[j+1][k] = vChord[j][k];

                            for(j = 0; j<trackIndex; j++)
                                vChord[vChordIndex+i-1][j] = ((ulong)UINT_MAX << 32);
                            vChord[vChordIndex+i-1][trackIndex] = pnote;
                            vChord[vChordIndex+i-1][VNOTESIZE-1] = trackIndex+1;
                            N++;

                            memmove(&(vTrackTime[i+1]), &(vTrackTime[i]), sizeof(int)*(vTrackTime[0]-i+1));
                            vTrackTime[i] = newTrackTime;
                            vTrackTime[0] ++;	//size++

                            find = true;
                            break;
                        }
                    }

                    //can't find a right place, add the note to the end of vChord
                    if(find == false)
                    {
                        ulong ptemp = ((ulong)UINT_MAX << 32);	//pitch INT_MAX, duration 0
                        int j = 0;
                        for(j=0; j<trackIndex; j++)
                            vChord[N][j] = ptemp;				//rest
                        vChord[N][trackIndex] = pnote;
                        vChord[N][VNOTESIZE-1] = trackIndex+1;
                        N++;
                        //printf("%ld %d.\n", N, trackIndex);

                        vTrackTime[0]++;
                        vTrackTime[ vTrackTime[0] ] = newTrackTime;
                    }

                }
                newTrackTime += (pnote & INT_MAX);	//add duration
            }

            //find a triplet
            if (strstr(str,"\\times"))
                triplet = 2./3;

            //find "}"
            if (strstr(str,"}")&&(triplet != 1))
                triplet = 1;
        }
    }
}

void parseMeasure(char *str, ulong vChord[VCHORDSIZE][VNOTESIZE], int vChordIndex)
{
    char *p;
    int trackIndex = 0;
    int vTrackTime[256];
    memset(vTrackTime, 0, 256*sizeof(int));
    for (; str; str = p)
    {
        if ((p = strstr(str, "\\\\"))) *(p++) = 0, *(p++) = 0;
        parseTrack(str, vChord, vChordIndex, trackIndex++, vTrackTime);
//	  int i = 0;
//	  for(i=1; i<=vTrackTime[0]; i++)
//		  printf("%d ", vTrackTime[i]);
//	  printf("\n");
    }
}

void mergeTies(ulong vChord[VCHORDSIZE][VNOTESIZE], int trackNO)
{
//	printf("trackNO: %d.\n", trackNO);
    int i = 0, j = 0, k = 0;
#if 0
    for(i=0; i<N; i++)
    {
		if((int)vChord[i][VNOTESIZE-1] == 1)
			continue;
        //find out the min duration
        unsigned int min = UINT_MAX;
        for(j=0; j<(int)vChord[i][VNOTESIZE-1] && j<sizeof(ulong); j++)
        {
            unsigned int duration = (vChord[i][j] & UINT_MAX);
            if(duration < min && duration != 0)
                min = duration;
        }

        //for(j=0; j<(int)vChord[i][VNOTESIZE-1]; j++)
        for(j=0; j<trackNO; j++)
		{
			//modify duration
			if( j < (int)vChord[i][VNOTESIZE-1])
			{
				int duration = (vChord[i][j] & UINT_MAX);
	            if(duration > min || duration == 0)	//set duration to be min
				{
					ulong pitch = (vChord[i][j] >> 32 ); 
					ulong mpitch = (pitch << 32 );	//add a mask, then move pitch
					vChord[i][j] = (mpitch | min);
			//		printf("min: %d duration: %d\n", min, duration);
				}
			}
			else
			{
				ulong pitch = (vChord[i-1][j]>>32);
				ulong mpitch = (pitch << 32);
				vChord[i][j] = (mpitch | min);
				vChord[i][VNOTESIZE-1]++;
			}
			//Rest: set pitch to be the last pitch | duration
            if( (vChord[i][j]>>32)==(unsigned int)-1 && i!=0)
                vChord[i][j] = ((vChord[i-1][j]&((ulong)UINT_MAX<<32)) | min);
        }
    }
#endif
	//set ties
	for(i=0; i<N-1; i++)
	{
		for(j=0; j<(int)vChord[i][VNOTESIZE-1]; j++)
		{
			int pitch1 = (vChord[i][j] >> 32 );
			for(k=0; k<(int)vChord[i+1][VNOTESIZE-1]; k++)
			{
				int pitch2 = (vChord[i+1][k] >> 32 ); 
				if(pitch1 == pitch2 && pitch1 != 0)	//same: set a mask
				{
					ulong duration = (vChord[i][j] & UINT_MAX);
					ulong mpitch = ( (ulong)(pitch1 | 128)<<32 );	//add a mask, then move pitch
					vChord[i][j] = (mpitch | duration); 
				}
			}

		}	
	}

#if 0
	//remove first rests
	for(i=0; i<N-1; i++)
		for(j=0; j<(int)vChord[i][VNOTESIZE-1]; j++)
		{
			//not a rest
			if( (vChord[i][j] >> 32 ) != (unsigned int)-1)
				break;
		}

	if(i==0)
		return;
	int number = i;
	for(i=0; i<N-1; i++)
        memmove(&(vTrackTime[i][number-1]), &(vTrackTime[i][number]), sizeof(int)*(N-i));
#endif
}

//convert the lilypond format file into internal data structure
//ulong **vChord
void readLY(char *fileName, ulong vChord[VCHORDSIZE][VNOTESIZE])
{
    char buf[1<<16];
    int vChordIndex;
    FILE *f;
	N=0;
    if (!(f = fopen(fileName,"r"))) {
        printf("Unable to open Lilypond format file: %s",fileName);
        _exit(1);
    }
    for (vChordIndex = 0; fgets(buf, 1<<16, f); )
        if (!checkStringComment(buf) && strstr(buf,"<<")) {
            parseMeasure(buf, vChord, vChordIndex);
            vChordIndex = N;
        }
    fclose(f);
}


/*********************************************************************
Conversion between Note Notations, String/Fret, Piano Keys, Midi Number
*********************************************************************/

// note_string -> hash
#define hash(str) ((((str)[0]-'0')<<5)+(((str)[1]-'a')<<2)+((str)[2]&3)) // - 01, + 11

void dehash(int number, char *note) // hash -> note_string
{
    *(note++) = '0' + (number>>5);
    *(note++) = 'a' + (7&(number>>2));
    *(note++) = 46  - (3& number);
    *note     = 0;
}

void initNoteStringArray() // string to pitch (midi number)
{
    int h,i,j,k, a[256], b[3] = {'-',0,'+'};
    char s[3];

    a['c'] = 12;  // midi number for c0 ...
    a['d'] = 14;
    a['e'] = 16;
    a['f'] = 17;
    a['g'] = 19;
    a['a'] = 21;
    a['b'] = 23;

    for (h = '0'; h < '8'; h++)                                   // octave
        for (s[0] = h, i = 'a'; i < 'h'; i++)                       // note
            for (s[1] = i, j = 0; j < 3; j++) {                       // flat, natural, sharp
                s[2] = b[j];
                k    = j-1 + 12*(h-'0') + a[i];
                NoteStringArray[hash(s)] = k;                           // hash2pitch
                NoteStringArray[256+k] = (s[2]<<16) + (s[1]<<8) + s[0]; // pitch2note_string
            }
}

int NoteString2Pitch( char *str) // note_string -> pitch
{
    if (strcmp(str,"rest"))
        return NoteStringArray[hash(str)];
    return -1;
}

void pitch2NoteString(int pitch, char *str) // pitch -> note_string
{
    int k;

    if (pitch == -1) {
        strcpy(str,"rest");
        return;
    }
    k = NoteStringArray[256+pitch];
    str[0] = 255&k;
    str[1] = 255&(k>>8);
    str[2] = 255&(k>>16);
    str[3] = 0;
    return;
}

void initPitchPositions() //calculate all positions for each pitch
{
    int i,fret,pitch;
    ulong l;

    for (pitch = 21; pitch < 108; pitch++) {
        for (l = i = 0; guitarString[i]; i++) {
            fret = pitch - NoteString2Pitch(guitarString[i]);
            if (-1 < fret && fret < FRET_MAX)
                l = (l<<8) | position2Char(i,fret);
        }
        PitchPositionArray[pitch] = l;
    }
}

int MidiToKeyNumber(int MidiNumber)
{
	return MidiNumber - 8;
}

void KeyNumberToNote(int PianoKeyNumber, char *n)
{
	//because "%", the result belongs to [0, PIANOOCTAVEKEYNUMBER-1]
	int index = (PianoKeyNumber+9)%PIANOOCTAVEKEYNUMBER-1;
	n[0] = ((PianoKeyNumber+9) / PIANOOCTAVEKEYNUMBER) + '0';
	if ( index < 0 )
	{
		n[0]--;
		index+=PIANOOCTAVEKEYNUMBER;
	}
	n[1] = pianoKeyBoard[index][0];
	n[2] = pianoKeyBoard[index][1];
	n[3] = '\0';
}

/*********************************************************************
Print functions
*********************************************************************/

static inline void printChordPosition(ulong l)
{
    if (l == (ulong)-1)
        printf("Rest");
    else
        for (; l; l >>= 8) {
            printf("<%d, %d> ", char2String(255&l)+1, char2Fret(255&l));
        }
}

//possibility: p1, p2, p3...pn
//p1*p2*...pn = pow(10, log10(p1*p2...pn)) = pow(10, log10(p1)+log10(p2)+...log10(pn));
void printChordPositions(chords n)
{
    int i;
    node *p;
	double total=0;

    for (i = 0; (p = *n); n++) {
		int j=0;
        printf("Chord %d Positions:\n",i++);
        if (p->d == (ulong)-1) {
            printf("Rest\n");
			j++;
			printf("%d possibilities.\n", j);
			total = total*j;
            continue;
        }
        for (; p; p = p->n) {
            printChordPosition(p->d);
            putchar('\n');
			j++;
        }
		printf("%d possibilities.\n", j);
		total += log10(j);
    }
	printf("After Note Tree Generation:\n");
	printf("10^%lf possibilities in total.\n", total);
    putchar('\n');
}

static inline void printChordPath(path n)
{
/*
    node *p;
    double r = 0;
    for (; (p = *n); n++) {
        r = p->r;
        if (p->d == (ulong)-1) {
            printf("Rest\n");
            continue;
        }
        printChordPosition(p->d);
        putchar('\n');
    }
	*/
	path p = n;
	for (; (*p)!=NULL; p++) {
        if ((*p)->d == (ulong)-1) {
            printf("Rest\n");
            continue;
        }
		printf("%ld th Chord: ", p-n);
        printChordPosition((*p)->d);
        putchar('\n');
    }
}

void printPaths(paths *z)
{
/*    int i = z->s;
    while (i--) {
        if (z->b[i] != (path)z) {
            printChordPath(z->b[i]);
            printf("fitness %lf\n\n", z->f[i]);
        }
    }
*/
	int i = 0;
	for(i=0; i<z->s; i++)
	{
		if(z->b[i] != (path)z)
		{
            printf("\n\n%dth Result: fitness %lf\n", i, z->f[i]);
			printChordPath(z->b[i]);
		}
		else
			return;
	}
}

//Measure Duration: 784, 1/4 192
void printVChord(ulong vChord[VCHORDSIZE][VNOTESIZE], int mduration)
{
    printf("Input: <Pitch, Duration, Notation>\n");
    int i = 0, j = 0;
    for(i=0; i<N; i++)
    {
        printf("Chord %d\n", i);
        for(j=0; j<(int)vChord[i][VNOTESIZE-1]; j++)
        {
            unsigned int pitch = (vChord[i][j]>>32);//remove the pitch mask
			unsigned int duration = (vChord[i][j]&UINT_MAX);
			char ctemp[16];
			memset(ctemp, '\0', 16);
			double durationName = mduration*1.0/duration;
			if(fabs(durationName - (int)durationName) > 0.01)	//fraction
				sprintf(ctemp, "%d/%d", duration, mduration);
			else
				sprintf(ctemp, "%d", (int)durationName);

            if(pitch == (unsigned int)-1 || pitch == 0)
			{
				printf("<Rest, %d, %s> ", duration, ctemp);
				continue;
			}
			int mask = (pitch & 128);
            pitch = (pitch & 127); //remove the pitch mask
			if(mask != 0)	//no ties
				printf("<%d~, %d, %s> ", pitch, duration, ctemp);
			else
				printf("<%d, %d, %s> ", pitch, duration, ctemp);

        }
        printf("\n");
    }
    printf("\n");
}

#if 0
void writePath2LY(ulong vChord[VCHORDSIZE][VNOTESIZE], ulong *p, int measureDuration, char *fileName)
{
	printf("\n\n");

	FILE *fp = fopen(fileName, "w");
	if(fp == NULL)
	{
		fprintf(stderr, "Can't generate LilyPond file.\n");
		exit(0);
	}

	fprintf(fp, "\\version \"2.16.0\"\n");
	fprintf(fp, "custom-tuning = \\stringTuning <e a d' g' b' e''>\n");
	fprintf(fp, "music = <<\n");
	fprintf(fp, "\t\t\\set midiInstrument = #\"acoustic guitar (steel)\"\n");
	fprintf(fp, "\t\t\\key a \\major\n");
	fprintf(fp, "\t\t\\time 4/4\n");

	//compute the duration and triplet
	int duration[VCHORDSIZE][VNOTESIZE];
	memset(duration, '\0', sizeof(duration));
	bool triplet[VCHORDSIZE][VNOTESIZE]; 
	memset(triplet, '\0', sizeof(triplet));
	int i = 0, j = 0, track = 0;
	for(i=0; i<N; i++)
	{
		if(track < (int)vChord[i][VNOTESIZE-1])
			track = (int)vChord[i][VNOTESIZE-1];
        for(j=0; j<(int)vChord[i][VNOTESIZE-1]; j++)
		{
			unsigned int d = (vChord[i][j]&UINT_MAX);
			if(d==0)
			{
				duration[i][j] = 0;
				continue;
			}
			int durationName = measureDuration*1.0/d;
			if(durationName%3 == 0)
			{
				triplet[i][j] = true;
				duration[i][j] = (int)(durationName*2/3);
			}
			else
				duration[i][j] = durationName;
		}
	}
	
	for(j=0; j<track; j++)
	{
		path p = pa;	//path pointer
		fprintf(fp, "\t%%track %d\n", j);
		fprintf(fp, "\t { ");
		for(i=0; i<N; i++)
	    {
			if(*p == NULL)
			{
				fprintf(stderr, "Wrong guitar Tab: %d %d\n", i, j);
				continue;
			}

			//starting triplet
			if( (i==0 && triplet[i][j]) || (i>=1 && !triplet[i-1][j] && triplet[i][j]) )
				fprintf(fp, "\\times 2/3 {");
			//ending triplet
			if( i<N-1 && triplet[i-1][j] && !triplet[i][j]) 
				fprintf(fp, "} ");

			if(j<(int)vChord[i][VNOTESIZE-1])
			{
				unsigned int pitch = (vChord[i][j]>>32);
			//  if(pitch == (unsigned int)-1)
				if(pitch == 0 || duration[i][j] == 0)
				{
					if(pitch == 0 && duration[i][j]!=0)
						fprintf(fp, "r%d ", duration[i][j]);	//rest
					p++;		//path pointer moves forward
					continue;
				}

				int mask = (pitch & 128);
				pitch = (pitch & 127); //remove the pitch mask
				char pitchName[bufferSize];	
				memset(pitchName, '\0', bufferSize);
				convertPitch2HPN(pitchName, pitch);	//pitch note notation
				
				ulong n = (*p)->d;	//chord playing position
				if(mask != 0)	//no ties
					fprintf(fp, "%s~%d\\%d ", pitchName, duration[i][j], char2String(255&n)+1);
				else
					fprintf(fp, "%s%d\\%d ", pitchName, duration[i][j], char2String(255&n)+1);

			//	printf("%d %d %d: ", i, j, (int)vChord[i][VNOTESIZE-1]);
			//	printChordPosition(n);
			//	printf("\n");
				((*p)->d) >>= 8;
			}
			//ending triplet
			if(i==N-1 && triplet[i][j])
				fprintf(fp, "} ");
			p++;		//path pointer moves forward
		}
		fprintf(fp, "}\n");
	}
    fprintf(fp, ">>\n");

	fprintf(fp, "\\layout { \\override Voice.StringNumber #'stencil = ##f }\n");
	fprintf(fp, "\\new StaffGroup <<\n");
	fprintf(fp, "  \\new Staff \\music\n");
	fprintf(fp, "  \\new TabStaff {\n");
	fprintf(fp, "    \\set TabStaff.stringTunings = #custom-tuning\n");
	fprintf(fp, "    \\music\n}>>\n");

	fclose(fp);
}
#endif

void writeVChord2LY(ulong vChord[VCHORDSIZE][VNOTESIZE], path pa, int measureDuration, char *fileName)
{
	printf("\n\n");

	FILE *fp = fopen(fileName, "w");
	if(fp == NULL)
	{
		fprintf(stderr, "Can't generate LilyPond file.\n");
		exit(0);
	}

	fprintf(fp, "\\version \"2.16.0\"\n");
	fprintf(fp, "custom-tuning = \\stringTuning <e a d' g' b' e''>\n");
	fprintf(fp, "music = <<\n");
	fprintf(fp, "\t\t\\set midiInstrument = #\"acoustic guitar (steel)\"\n");
	fprintf(fp, "\t\t\\key a \\major\n");
	fprintf(fp, "\t\t\\time 4/4\n");

	//compute the duration and triplet
	int duration[VCHORDSIZE][VNOTESIZE];
	memset(duration, '\0', sizeof(duration));
	bool triplet[VCHORDSIZE][VNOTESIZE]; 
	memset(triplet, '\0', sizeof(triplet));
	int i = 0, j = 0, track = 0;
	for(i=0; i<N; i++)
	{
		if(track < (int)vChord[i][VNOTESIZE-1])
			track = (int)vChord[i][VNOTESIZE-1];
        for(j=0; j<(int)vChord[i][VNOTESIZE-1]; j++)
		{
			unsigned int d = (vChord[i][j]&UINT_MAX);
			if(d==0)
			{
				duration[i][j] = 0;
				continue;
			}
			int durationName = measureDuration*1.0/d;
			if(durationName%3 == 0)
			{
				triplet[i][j] = true;
				duration[i][j] = (int)(durationName*2/3);
			}
			else
				duration[i][j] = durationName;
		}
	}
	
	for(j=0; j<track; j++)
	{
		path p = pa;	//path pointer
		fprintf(fp, "\t%%track %d\n", j);
		fprintf(fp, "\t { ");
		for(i=0; i<N; i++)
	    {
			if(*p == NULL)
			{
				fprintf(stderr, "Wrong guitar Tab: %d %d\n", i, j);
				continue;
			}

			//starting triplet
			if( (i==0 && triplet[i][j]) || (i>=1 && !triplet[i-1][j] && triplet[i][j]) )
				fprintf(fp, "\\times 2/3 {");
			//ending triplet
			if( i<N-1 && triplet[i-1][j] && !triplet[i][j]) 
				fprintf(fp, "} ");

			if(j<(int)vChord[i][VNOTESIZE-1])
			{
				unsigned int pitch = (vChord[i][j]>>32);
			//  if(pitch == (unsigned int)-1)
				if(pitch == 0 || duration[i][j] == 0)
				{
					if(pitch == 0 && duration[i][j]!=0)
						fprintf(fp, "r%d ", duration[i][j]);	//rest
					p++;		//path pointer moves forward
					continue;
				}

				int mask = (pitch & 128);
				pitch = (pitch & 127); //remove the pitch mask
				char pitchName[bufferSize];	
				memset(pitchName, '\0', bufferSize);
				convertPitch2HPN(pitchName, pitch);	//pitch note notation
				
				ulong n = (*p)->d;	//chord playing position
				if(mask != 0)	//no ties
					fprintf(fp, "%s~%d\\%d ", pitchName, duration[i][j], char2String(255&n)+1);
				else
					fprintf(fp, "%s%d\\%d ", pitchName, duration[i][j], char2String(255&n)+1);

			//	printf("%d %d %d: ", i, j, (int)vChord[i][VNOTESIZE-1]);
			//	printChordPosition(n);
			//	printf("\n");
				((*p)->d) >>= 8;
			}
			//ending triplet
			if(i==N-1 && triplet[i][j])
				fprintf(fp, "} ");
			p++;		//path pointer moves forward
		}
		fprintf(fp, "}\n");
	}
    fprintf(fp, ">>\n");

	fprintf(fp, "\\layout { \\override Voice.StringNumber #'stencil = ##f }\n");
	fprintf(fp, "\\new StaffGroup <<\n");
	fprintf(fp, "  \\new Staff \\music\n");
	fprintf(fp, "  \\new TabStaff {\n");
	fprintf(fp, "    \\set TabStaff.stringTunings = #custom-tuning\n");
	fprintf(fp, "    \\music\n}>>\n");

	fclose(fp);
}

/****************************************************************
Generate chord positions
****************************************************************/
static node *get_node(ulong l) // l chord position
{
    uint a,b,c,d,f;
    node *n;
    float s[6];// = SPREAD_PENALTY;
	int i=0;
	for(i=0; i<6; i++)
		s[i]=(float)SPREAD_PENALTY[i];

    n = (node *)malloc(sizeof(node));
    n->n = NULL;
    n->d = l;
    n->c = 0;
    if (l == (ulong)-1) n->p = l = 0;
    for (a = ~(b = c = d = 0); l; l >>= 8) {
        d |= ((f = char2Fret(255&l)) > HIGH_FRET);    // high fret?
        if (f) {
            if (f < a) a = f;                           // min fret
            if (f > b) b = f;                           // max fret
        } else {
            c++;                                        // count open strings
        }
    }
    n->s  = ((b)? b-a: 0);                          // spread
    n->f  = s[n->s];                                // spread penalty
    n->f += d*LARGE_FRET;                            // large fret penalty
    n->f += c*(float)OPEN_STRING;                    // open string reward
    n->a  = ((b)? (b+a)/2.: 0.);                    // average fret position
    if (n->a) n->s = (b<<8)|a;                      // max, min
    return n;
}

paths *get_paths(int i)
{
    paths *p = (paths *)malloc(sizeof(paths));

    p->s = i;
    p->b = (path   *)malloc(i*sizeof(chords));
    p->f = (double *)malloc(i*sizeof(double));
    p->n = (ulong  *)calloc(i,sizeof(ulong ));
    while (i--) p->b[i] = (path)p;             // initialize b
    return p;
}
static inline ulong reverse(ulong l) // reverse bytes
{
    ulong r;
    for (r = 0; l; l>>= 8) r = (r<<8)|(255&l);
    return r;
}

//build chord positions from notes in l (explore note tree)
//size: how many possiblity are there in total
node *initChordPositions(ulong l, int *size)
{
    int d,h,i,j,k,f,g;
    uint c[6], s[1<<10];
    ulong p;
    node*n, *q = NULL, *r= NULL;
	*size=0;
    for(i = 0, p = PitchPositionArray[127&l]; p; p>>=8)      // (mask tie bit)
        s[i++] = p&255;                                      // push positions for the first note on stack

    while (i) {                                              // stack not empty
        h      = s[--i];                                       // pop stack
        d      = h>>8;                                         // depth
        c[d++] = h&255;                                        // save position
        p      = 127&(l>>(8*d));                               // next note (mask tie bit);
        if (p) {
            for (j = d<<8, p = PitchPositionArray[p]; p; p>>=8) { // j encodes depth
                h = char2String(255&p);                            // string
                f = char2Fret(255&p);                              // fret
                for (k = 0; k < d; k++) {
                    if ((h == char2String(c[k]))||                   // same string
                            (f&&((g = char2Fret(c[k])))&&abs(f-g)>5))    // frets too far apart
                        goto prune;
                }
                s[i++] = j|(p&255);                                // embed depth, push on stack
prune:
                continue;
            }
            continue;
        }
        while (d--) p = (p<<8)|c[d];                           // make chord position
        (n = get_node(p))->p = reverse(l);               // save position and notes
        q = ((q)? (q->n = n): (r = n));                        // save chord position
		(*size)++;
    }
    return r;
}

#define FUDGE -12
int factorial(int n)
{
	return (n == 1 || n == 0) ? 1 : factorial(n - 1) * n;
}

//max: max chord playing possiblities
chords chordPositions(ulong vChord[VCHORDSIZE][VNOTESIZE], int *max)
/* return positions; array of: list of playing positions */
{
    int h,j,k;
    ulong i,l;
    byte c[8];
    node *p,**q;
	*max = 0;

	//calculate the total possibilities
	//each note: 6 playing possibilities; each chord(n notes in the chord): pow(6, n)
	//possibility: p1, p2, p3...pn
	//p1*p2*...pn = pow(10, log10(p1*p2...pn)) = pow(10, log10(p1)+log10(p2)+...log10(pn));
	double total=0;
	for(i=0; i<N; i++)
		total += log10(pow(6, (int)vChord[i][VNOTESIZE-1]));
	printf("10^%lf possibilities in total.\n", total);
	
	uint  *chordIndex = (uint  *)malloc(N*sizeof(uint));
    ulong *chord      = (ulong *)malloc(N*sizeof(ulong));
    chords positions  = (chords )calloc(1+N, sizeof(node *));  // NULL terminated

    for (h = i = 0; i < N; i++) {                              // traverse chords
        for (l = j = k = 0; j < (int)vChord[i][VNOTESIZE-1]; j++) 
		{    // traverse ituent notes
			int pitch = ((vChord[i][j]>>32)&127);
            if ( pitch != -1 && pitch != 0)                       // rest, mask 127
			{//	printf("%d\n", pitch);
                c[k++] = FUDGE + pitch;							// save pitch (collect chord)
			}
        }
        if (k) {                                                 // chord (c) has notes
            while (k--) {                                        // sort ituent pitches
                for (j = 0; j < k; j++)                          // bubble sort
                    if (c[j] < c[j+1])
                        c[j] ^= c[j+1], c[j+1] ^= c[j], c[j] ^= c[j+1];  // swap
                l = (l<<8) | c[k];                                   // save note (collect normalized chord)
            }
            for (k = 0; k < h; k++) if (l == chord[k]) break;     // new chord? (linear search)
            if (k == h) {                                         // yes
                chord[h] = l;                                     // save chord
                chordIndex[h++] = i;                              // save index (into positions)
				int size = 0;
                positions[i] = initChordPositions(l, &size);// build noteTree (at chordIndex[k])
				(*max < size)? (*max=size): 1;
            } else {                                              // copy list
                q = positions+i;
                for (p = positions[chordIndex[k]]; p; p = p->n, q = &((*q)->n)) {
                    memcpy(*q = (node *)malloc(sizeof(node)), p, sizeof(node));
                    (*q)->n = NULL;
                }
            }
        } else {
            positions[i] = get_node((ulong)-1);                    // rest
        }
    }
    free(chordIndex);
    free(chord);
    return positions;
}

/****************************************************************
Fitness function
****************************************************************/
// from p to q, l = last chord average position
float betweenChordFitness(node *p, node *q, float l) 
{
    int h,i,j,k,u,v,f[6];
    float fitness;
    ulong a,b,c;
    float s[6];// = SPREAD_PENALTY;
	for(i=0; i<6; i++)
		s[i]=(float)SPREAD_PENALTY[i];

    for (h = i = 0, a = p->p, b = p->d; a; a>>=8, b>>=8) { // traverse p: a = notes, b = positions
        if (128&a) {                                       // tied note
            j = 1;
            if (char2Fret(255&b)) {                        // not open string
                for (c = q->d; c; c>>=8)                   // traverse q: c = positions
                    if ((255&c) == (255&b)) {
                        j = 0;                             // note continues
                        break;
                    }
            } else {
                j = 0;
                k = char2String(255&b);                    // open string
                for (c = q->d; c; c>>=8) {                 // traverse q: c = positions
                    if ((255&c) == (255&b))
                        break;                             // note continues
                    if (k == char2String(255&c)) {         // same string (not open)
                        j = 1;
                        break;
                    }
                }
            }
            i += j;                                         // accumulate broken ties
        } else {                                            // check ringing
            f[h++] = char2Fret(255&b);                      // potential ringing (fret)
            k = char2String(255&b);                            // potential ringing (string)
            for (c = q->d; c; c>>=8)                           // traverse q: c = positions
                if (k == char2String(255&c)) {
                    h--;
                    break;                                    // string in use
                }
        }
    }
    fitness = i*BROKEN_TIE;
    if (h) {                                               // ringing
        if (q->a) {                                          // not all open strings
            k = 255&(q->s>>8);                                 // max fret (q)
            j = 255&q->s;                                      // min fret (q)
            while (h--) {
                if ((u = abs(f[h] - k)) < (v = abs(f[h] - j)))
                    u = v;
                if (u < 5) fitness += RINGING + s[u];            // partial reward
            }
        } else fitness += h*RINGING;                         // all open strings
    }
    if (q->a) {                                            // not all open strings
        if (p->a)
            fitness += fabsf(p->a - q->a);                     // hand movement
        else if (l)
            fitness += fabsf(l - q->a);                        // hand movement using last
    }
    return fitness;
}

/***************************************************************
Build the chord tree to generate the guitar tab
****************************************************************/

int saveChordPath(ulong n, path t, paths *z)
{
    ulong h;
    int i = -1, j = z->s-1;
    node **s;

    while (i++ < j) {                                // traverse b (insertion sort)
        s = NULL;
        if (z->b[i] != (path)z) {                      // occupied position
            if (z->f[i] < t[n-2]->r) continue;           // t is not better
            for (s = z->b[j], h = z->n[j]; j > i; j--) { // save last and shift down
                z->b[j] = z->b[j-1];
                z->f[j] = z->f[j-1];
            }
        }
        if (s && (s != (path)z)) {                     // valid old path
            if (n > h) {                               // old path too small
                free(s);                               // free old path
                goto l;
            }
            z->b[i] = s;                               // reuse space
            z->n[i] = n;                               // set size
        } else {
l:
            z->b[i] = (path)malloc(n*sizeof(node *));    // new space (for copy)
            z->n[i] = n;
        }
        for (s = z->b[i]; *t; *s++ = *t++);            // copy array (top level of t)
        *s = NULL;                                     // terminate path
        z->f[i] = (*--t)->r;                           // save fitness
        return i;
    }
    return -1;
}

void sortChord(node *a[], int n) // increasing
{
    int i,j,k;
    node *p;

    for (i = 0; i < n; i++) {
        for (k = j = i; j < n; j++)        // find minimum in a[i..i-1]
            if (a[j]->r < a[k]->r) k = j;  // index of minimum
        p    = a[i];                       // swap
        a[i] = a[k];
        a[k] = p;
    }
}

// n contains N+1 > 0 pointers, only the last of which is NULL
// c is a raint, the result is wanted to be the same as c
//[begin, end]: generate the guitar tab between n[begin] ~ n[end]
int branchAndBound(chords n, paths *z, path c, int begin, int end) 
{
    int h,i,k, e = end;
    ulong d,j;
    float l,f;
    node **s,**t,*p,*q,*r,*a[1<<10];
	size_t total=0;

    M++;                                                      // reset
    s = (path)malloc(e*sizeof(node *));                       // stack
    t = (path)malloc(e*sizeof(node *));                       // path

    for (k = 0, q = n[begin]; q ; q = q->n) {
        q->r   = q->f;                                        // initial fitness from root(within fitness)
        a[k++] = q;                                           // copy chords
    }
    sortChord(a,k);                                           // sort
    for (i = d = 0; k--; a[k]->c = M) {
        s[i++]  = a[k];                                       // push the first chords on stack
    }
    while (i) {                                               // stack not empty: i stack index
        p      = s[--i];                                        // pop stack
        d      = h = (p->s)>>16;                                // depth
        if (c && c[d] && (p != c[d])) continue;                 // prune if raint not met
        t[d++] = r = p;                                         // save position
        if ((p = n[d])) {                                       // next chord
            for (l = 0; h--&&!((l = t[h]->a)););                  // find last position: not rest
            for (j = d<<16, k = 0, q = p; q; q = q->n) {          // next chords: p current, q next
                f = r->r + q->f + betweenChordFitness(r,q,l);       // finess from root: r current
                if (q->c < M) q->c = M, q->r = f;                   // initialize
                else if (q->r < f) continue;                        // prune
                q->r = f;
                a[k++] = q;                               // update fitness, push on a
            }
            if (k) sortChord(a,k);                                // sort (increasing fitness)
            while (k--) {                                         // push chords on stack
                if (i == e)                                         // grow stack
                    s = (chords)realloc(s, (e += e)*sizeof(node *));
                s[i++]  = a[k];                                     // push smallest (best) last
                a[k]->s = j|(65535&(a[k]->s));                      // embed depth
            }
            continue;
        }
        t[d] = NULL;
		total++;
        saveChordPath(N+1,t,z);	//N+1
    }
    free(s);
    free(t);
	printf("After Chord Tree Generation:\n");
	printf("%ld possibilities in total\n", total);
    for (h = -1, i = 0; i < z->s; i++)
        if (z->b[i] != (path)z) h = i;                        // occupied position
    return h;                                                 // number of saved paths
}


/***************************************************************
Breadth first search
 ****************************************************************/
int index2D(int i, int j, int size2)
{
	return i*size2+j;
}

int index3D(int i, int j, int k, int size2, int size3)
{
	return i*size2*size3+j*size3+k;
}

void BFSearch(chords n, pathElement *pathStorage, int size1, int size2, int size3)
{
    node *lastp = *n, *currentp = *n; 
	int i = 0, j = 0, k=0, l=0;			//which level, current playing position, last playing position, 0~100
	pathElement *pe = (pathElement *)malloc(size2*size3*sizeof(pathElement));	//temporary storage
	//size2: how many playing positions in the current level; size3: how many possibilities in the last level
	int *mindex = (int *)malloc(sizeof(int)*size3);		//store the path index for each group
	//pathStorage initialization
	memset(pathStorage, -1, size1*size2*size3*sizeof(pathElement));

	for (i = 0; (currentp = *n); n++, i++) 
	{
		node *pi = *n;
        if (pi->d == (ulong)-1)		//rest 
		{
			for(j=0; j<size2; j++)
			{
				for(k=0; k<size3; k++)
				{
					int index1 = index3D(i-1, j, k, size2, size3);
					int index2 = index3D(i, j, k, size2, size3);
					pathStorage[index2] = pathStorage[index1];
				}
			}
			continue;
		}
		if(!i)					//the first non-rest level
		{
			for(j=0; pi; pi=pi->n, j++)
			{
				int index3 = index3D(i, j, 0, size2, size3);
				pathStorage[index3].j = j, pathStorage[index3].k = 0;
				pathStorage[index3].f = pi->f; //within fitness
			}
			continue;
		}

		//initialize temporary space
		memset(pe, -1, size2*size3*sizeof(pathElement));
		
		for (j=0; pi; pi = pi->n, j++)					//j goes through each playing position in the current level 
		{
			node *lastpi = lastp;
			for(k=0; lastpi; lastpi=lastpi->n, k++)	//k goes through each playing position in the previous level
			{
				float nf = betweenChordFitness(lastpi, pi, lastpi->a) + pi->f;  //newly fitness added to the path
				for(l=0; l<size3; l++)				//l goes through each path for the previous playing position
				{
					int index3 = index3D(i-1, k, l, size2, size3);
					if(pathStorage[index3].j == -1)
						break;
					int index2 = index2D(k, l, size3);
					pe[index2].j = k, pe[index2].k = l;
					pe[index2].f = pathStorage[index3].f + nf;
				}
			}
			
			//merge sort
			memset(mindex, '\0', sizeof(int)*size3);
			int size = 0;								//record the path size for current playing position path[i][j]
			while (1)
			{
				//find out the min fitness
				float min = FLT_MAX;					//float min
				int kIndex = -1;						//min is from which group?
				node *lastpi = lastp;					//begining address of the last level
				int find = 0;							//whether there is a new path
				for(k=0; lastpi; lastpi=lastpi->n, k++)	//k goes through each playing position in the previous level
				{
					int index = index2D(k, mindex[k], size3);
					if( min > pe[index].f && pe[index].f != -FLT_MAX)
						min = pe[index].f, kIndex = k, find = 1;
				}
			
				if(!find || size >= size3)				//no more new path
					break;

				//store the path with the smallest fitness
				int index = index3D(i, j, size, size2, size3);
				pathStorage[index].j = kIndex, pathStorage[index].k = mindex[kIndex];
				pathStorage[index].f = min;
				mindex[kIndex]++, size++;
			}
		}
		lastp = currentp;	//lastp: starting address of the last level
    }
	free(pe);
	free(mindex);
}

void print2DpathElement(pathElement *pathStorage, int size2, int size3)
{
	int j, k;
	for(j=0; j<size2; j++)
		for(k=0; k<size3; k++)
		{
			int index = index2D(j, k, size3);
			if(pathStorage[index].j != -1)
			{
				printf("\t(%d, %d): (%d, %d, %f).\n", j, k,  
						pathStorage[index].j, pathStorage[index].k, pathStorage[index].f); 
			}
		}
}

void printPathElement(pathElement *pathStorage, int size1, int size2, int size3)
{
	printf("%s:\n", __FUNCTION__);
	int i, j, k;
	for(i=0; i<size1; i++)
	{
		for(j=0; j<size2; j++)
		{
			for(k=0; k<size3; k++)
			{
				int index = index3D(i, j, k, size2, size3);
				if(pathStorage[index].j != -1)
				{
					printf("\t(%d, %d, %d)->%d: (%d, %d, %f).\n", i, j, k, index3D(i, j, k, size2, size3),
							pathStorage[index].j, pathStorage[index].k, pathStorage[index].f); 
				}
			}
		}
	}
}

//print the best "pathNumber" path:
//	size1->how many chords in total, size2->which chord playing position, size3->which path(1~100)
void printWholePath(pathElement *pathStorage, chords n, int size1, int size2, int size3, int pathNumber)
{
	printf("%s:\n", __FUNCTION__);
	int i, j, count=0, find=0;						//count: how many path have been printed
	int *mindex = (int *)malloc(size2*sizeof(int));
	memset(mindex, '\0', size2*sizeof(int));
	ulong *apath = (ulong *)malloc(size1*sizeof(ulong));
	memset(apath, 0, size1*sizeof(ulong));
	int pindex = -1;								//path index in the pathStorage array
	while(1)
	{
		for(i=size1-1; i>=0; i--)
		{
			node *p = n[i];							//begining address of level i
			if (p->d == (ulong)-1)					//rest 
			{
				//printf("Rest.\n");
				apath[i] = (ulong)-1;
				continue;
			}
				
			if(i==size1-1)								//find out the min fitness at the last level
			{
				float min = FLT_MAX;					//float min
				ulong l = 0;
				int jmin = 0;
				for(j=0; p; p=p->n, j++)				//j goes through each playing position in the level
				{
					int index = index3D(i, j, mindex[j], size2, size3);
					if( min > pathStorage[index].f && pathStorage[index].f != -FLT_MAX)
						min = pathStorage[index].f, pindex = index, l=p->d, find = 1, jmin = j;
				}
				if(!find || count>=pathNumber)			//no more new path
				{
					free(mindex);
					return;
				}
				apath[i] = l;
			
				//printf("%dth path: %f.\n", count, pathStorage[pindex].f);
				//printf("%dth Chord: (j: %d, k: %d, pindex: %d) -> (%dth, j: %d, k: %d): ", 
				//		i, jmin, mindex[jmin], pindex, i-1, pathStorage[pindex].j, pathStorage[pindex].k);
				//printChordPosition(l);
				//printf("\n");
				
				count++, mindex[jmin]++;
				continue;
			}
			
			//print the playing position at level i
			for(j=0; p&&j<pathStorage[pindex].j; p=p->n, j++)
			{
			}
			//pindex = index3D(i, pathStorage[pindex].j, pathStorage[pindex].k, size2, size3);
			//printf("%dth Chord: -> (%dth, j: %d, k: %d): ", 
			//		i, i-1, pathStorage[pindex].j, pathStorage[pindex].k);
			//printChordPosition(p->d);
			//printf("\n");
			apath[i] = p->d;

			if(i==0)	//print the path
			{
				for(j=0; j<size1; j++)
				{
					printf("%dth Chord: ", j);
					printChordPosition(apath[j]);
					printf("\n");
				}
			}
		}
		//printf("\n");
	}
	free(mindex);
	free(apath);
}

/***************************************************************
Divide and conquer
****************************************************************/
int getChordsPositionNumber(ulong l)
{
	int size = 0;
	for(; l; l>>=8)
		size++;
	return size;
}

//divide the chords into several part(conf->MidiPart).
//calcualte the guitar tab between [begin , end-1]
int divideAndConquer(chords n, paths *z, path c, int begin, int end) 
{
	if(end-begin-1 <=0)
		return 0;

	int MidiPart = 4;
	int i=0, j=0;
	paths *zpart[MidiPart];
	for(i=0; i<MidiPart; i++)
	{
		int pbegin = begin+(end-1-begin)*i/MidiPart, pend = begin+((end-begin)*(i+1))/MidiPart;
		pend = ((pend<end+1)?pend:end+1);
		int pbeginSize = getChordsPositionNumber(n[pbegin]->d);
		int pendSize = getChordsPositionNumber(n[pend-2]->d);
		printf("N: %ld range[%d, %d], size[%d, %d] .\n", N, pbegin, pend, pbeginSize, pendSize);
		zpart[i] = get_paths(BEST_RESULT);
		j = branchAndBound(n, zpart[i], c, pbegin, pend);	//j: how many saved path
	}

	//combine the result
	return j;
}

void freeChords(chords n)
{
    node *s,*p,**q;

    for (q = n; *q; q++)
        for (p = *q; p; p = s) {
            s = p->n;
            free(p);
        }
    free(n);
}

void freePaths(paths *z)
{
    int i = z->s;

    while (i--) if (z->b[i] != (chords)z) free(z->b[i]);
    free(z->b);
    free(z->f);
    free(z->n);
    free(z);
}

#if 0
void *branchAndBoundWrapper(void *vbbarg)
{
	BBArg *bbarg = (BBArg *)vbbarg;
	SETTINGS *conf = bbarg->conf;
	int threadid = bbarg->threadid;
	int begin = N*threadid/conf->GuitarThread;
	int end = (N*(threadid+1)+1)/conf->GuitarThread;
	end = ( (end>N+1)?(N+1):end );

	bbarg->j = branchAndBound(bbarg->n, bbarg->z, bbarg->c, conf, begin, end);	//j: how many saved path
	
	pthread_exit(0);
	return NULL;
}

int branchAndBoundPthread(chords n, paths *z, path c, SETTINGS *conf)
{
	if(conf->GuitarThread <=0 )
		conf->GuitarThread = 1;
	pthread_t thread_ID[conf->GuitarThread];
	BBArg bbarg[conf->GuitarThread];
	memset(bbarg, '\0', sizeof(BBArg) * conf->GuitarThread);

	int i;
	for(i=0; i<conf->GuitarThread; i++)
	{
		// Create the thread, passing &value for the argument.
		bbarg[i].threadid = i;
		bbarg[i].n = n, bbarg[i].z = z;
		bbarg[i].c = c, bbarg[i].conf = conf;
		pthread_create(&thread_ID[i], NULL, &branchAndBoundWrapper, (void *)(&(bbarg[i])));
	}

	// The main program continues while the thread executes.
	// Wait for the thread to terminate.
	void *exitstatus;
	for(i=0; i<conf->GuitarThread; i++)
		pthread_join(thread_ID[i], &exitstatus);

	return bbarg->j;	//return results number
}
#endif

int main(int argc, char *argv[])
{
	if(argc != 3)
	{
		fprintf(stderr, "Please follow the format: ./cTab inputMidi outputLY.\n");
		fprintf(stderr, "(./cTab out.midi out2.ly)\n");
		exit(0);
	}

	if (read_config()){
		fprintf(stderr, "Error reading \"guitarTab-config\"\n");
		exit(0);
	}

	//initialization
    initNoteStringArray();
    initPitchPositions();

	//input Lilypond format file to vChord(pitch, duration) and playing time(starting time, ending time)
    ulong vChord[VCHORDSIZE][VNOTESIZE];			//200 chords, 6 notes, 1 size
    ulong vChord1[VCHORDSIZE][VNOTESIZE];			//vChord copy
    memset(vChord, 0, sizeof(vChord));

	int trackNO = Midi2XML2(argv[1], "out1.xml", vChord);
	printVChord(vChord, MEASURE_DURATION);
//	readLY("1.ly", vChord);
//	int trackNO = 3;
	memcpy(vChord1, vChord, sizeof(vChord));
    mergeTies(vChord, trackNO-1);					//the first track is for configuration, no data in it
	//printVChord(vChord, conf->MEASURE_DURATION);
	int size2 = 0;	//max chord playing possibilities
    chords n = chordPositions(vChord, &size2);			//chord playing positions
	printChordPositions(n);

//Breadth First Search
#if 1
	int size1 = N, size3 = 100;
	size2++;
	pathElement *pathStorage = (pathElement *)malloc(size1*size2*size3*sizeof(pathElement));	//path storage matrix
	BFSearch(n, pathStorage, size1, size2, size3);
//	printPathElement(pathStorage, size1, size2, size3);
	printWholePath(pathStorage, n, size1, size2, size3, 1);
//	writeVChord2LY(vChord1, z->b[0], conf->MEASURE_DURATION, argv[2]);
	free(pathStorage);
#endif

//Depth First Search	
#if 0	
    paths *z = get_paths(conf->BEST_RESULT);
	int j = branchAndBound(n, z, NULL, conf, 0, N+1);	//j: how many saved path
//	int j = branchAndBoundPthread(n, z, NULL, conf);
//	ing j = divideAndConquer(n, z, NULL, conf, 0, N+1);
	printPaths(z);

	printf("\n=============================================================\n");
	printf("Please select the result: \n");
	int resultIndex=j, chordIndex1=3, chordIndex2=N, i=0;
	//int i = scanf("%d %d %d", &resultIndex, &chordIndex1, &chordIndex2);
    
	/* make a raint path */
	chords q;
/*	for (i = N+1, q = (chords)malloc(i*sizeof(node *)); i--; )
        q[i] = z->b[j][i];
    q[0] = q[1] = q[2] = NULL;
*/	
	q=(chords)malloc((N+1)*sizeof(node *));
	memset(q, 0, (N+1)*sizeof(node *));
	for(i=chordIndex1; i<=chordIndex2 && i<=N; i++)
		q[i] = z->b[resultIndex][i];

    freePaths(z);
    z = get_paths(conf->BEST_RESULT);
    branchAndBound(n,z,q, conf, 0, N+1);
    printPaths(z);

	writeVChord2LY(vChord1, z->b[0], conf->MEASURE_DURATION, argv[2]);
	free(q);
    freePaths(z);
#endif

    freeChords(n);
	return 0;
}

#endif

#if 0
gcc -Wall -O3 -o ctab guitarTab.c -lm

valgrind  --leak-check=full ./ctab
#endif
